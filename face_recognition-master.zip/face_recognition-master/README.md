# Login and signup app using SQLite databse
Simple login and signup app using SQLite database.
# Language
Kotlin
# IDE/ Tool
Android Studio
# Design Sample


![WhatsApp Image 2022-05-17 at 10 34 01 PM (1)](https://user-images.githubusercontent.com/77319741/168887890-ea50488f-42ef-45db-b625-f68f80d94e95.jpeg)
![WhatsApp Image 2022-05-17 at 10 34 01 PM](https://user-images.githubusercontent.com/77319741/168887902-0c1cc9e8-7ab5-48e0-96d0-a26ce9d167ba.jpeg)
![WhatsApp Image 2022-05-17 at 10 34 02 PM (1)](https://user-images.githubusercontent.com/77319741/168887905-9a92f6f1-35d2-46be-a758-e53aa42f3319.jpeg)
![WhatsApp Image 2022-05-17 at 10 34 02 PM](https://user-images.githubusercontent.com/77319741/168887909-4d5e0ccc-d9d9-406f-90a1-5028e8626df0.jpeg)
![WhatsApp Image 2022-05-17 at 10 34 03 PM](https://user-images.githubusercontent.com/77319741/168887913-7a4e910b-7590-4b08-81cb-e4c61e1e9b9f.jpeg)
![WhatsApp Image 2022-05-17 at 11 06 43 PM](https://user-images.githubusercontent.com/77319741/168887917-86a27f06-ccfa-4eb2-8741-592f2d72f062.jpeg)
