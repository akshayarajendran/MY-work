import androidx.annotation.NonNull;

public class SplashScreen {

    @NonNull
    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
